# Validation — 2026-09-05 speed and handling pass

## Sun, cloud shadows and time of day — 2026-09-05

Added a shared projected cloud field to the sky and opaque surface lighting, enabled nearby terrain shadow casting, and added Dawn / Day / Dusk / Night with an optional twenty-minute cycle. Direct light, sky, ambient fill and fog respond to both weather and time. Moonlight maintains night visibility. Weather/time selection remains presentation-only; the solver, benchmark identity and personal-best schema are unchanged.

### Headless checks

**45/45 physics and 72/72 runtime checks pass.** The fifteen additional runtime checks cover sun warmth/strength/direction, moon activation, weather-dependent night light, shared cloud parameters on sky/snow/skier, paused cloud motion, world-space wind displacement, Effects Off at night, frozen title/pause clocks, cycle timing and wrap, retained settings on restart, connected time controls, and at most one active shadow-casting light through the complete cycle. The deterministic descent still finishes in **55.702894 s** at **144.056772 km/h** peak, with no crash or airtime. These checks do not validate rendered appearance or sound.

### Native visual inspection

`tests/lighting_playtest.gd` produced **50 unranked captures at 1440 × 900** with no failed assertions or engine errors. They cover:

- Four weather presets × four times of day × both gameplay cameras (32 captures, with precipitation hidden to isolate illumination).
- A 48-position cloud sweep, with sunlit/shaded image pairs and a cloud-shadow-disabled control. The rendered snow probe changed by **0.130** luminance and the sun-facing orange sleeve by **0.184** on the same frames. The ambient-facing sleeve correctly retains its fill light. Values are differences in weighted screenshot RGB, not photometric measurements.
- Sun and moon disks, local geometry shadows, six twilight samples around sunrise/sunset, and the time/weather panel.
- Moving Snowfall/Rain in both cameras at night, entered at 120 km/h and captured at approximately 104 km/h after a second of skiing.

Inspection confirms coordinated patches of cloud shade on the skier and ground, warm dawn/dusk color, cooler overcast light, readable blue moonlit terrain, and local tree/skier shadows. The central route, nearby obstacles, ski tips and HUD remain visible through nighttime precipitation. The enlarged settings panel fits the viewport. The moon/sun transition retains ambient visibility while directional light fades. Lighting-harness FPS readings are replaced with an inspection label; its synchronous GPU readbacks are not a performance test.

The **35-capture weather matrix was also rerun** after reducing the snow allocation. Both cameras retain precipitation coverage at 30/120/200 km/h entry speeds, with a clear central route. The transition, Low/Off, V, pause, camera switch and restart checks remain successful. Final allocations are 600 snow + 900 rain + 200 ground particles on High (1,700 total), and half that on Low (850).

No audio layers changed in this lighting pass. Prior source-level and mute checks remain valid; no new subjective listening assessment is claimed.

### Performance method and evidence

Fresh full-descent runs use the same fixed 1440 × 900 native viewport, input and capture schedule, with separate elapsed-frame and viewport-render fields. `--autoplay` now enables Godot's [viewport render measurements](https://docs.godotengine.org/en/stable/classes/class_renderingserver.html#class-renderingserver-method-viewport-get-measured-render-time-gpu). This Metal run returns CPU render timing but no positive GPU timing, so GPU measurements are marked unavailable. Effects Off retains the new directional geometry shadows and selected time of day: this comparison measures weather overhead against current basic lighting, not every lighting change against the older build.

The early cloud-only comparison had variable desktop frame pacing: cloud shadows disabled gave p95 **12.179 ms** and **16.353 ms** across two runs, while enabled gave **9.061 ms**. This does not establish that shadows improve performance. The pre-change attempt used a resized 1476 × 900 viewport and is excluded from direct comparisons. The final fixed-size measurements below supersede those exploratory runs.

Profiling prompted two cost reductions: cloud transmission is now sampled per vertex and interpolated over the four-metre terrain grid, and the High snow volume was reduced from 900 to 600 flakes. Object shadows and material lighting still evaluate per pixel. Sky cloud noise remains at half resolution. The Snowfall benchmark was repeated after the allocation change; the other final rows use the same active rain/spindrift counts and cloud shader, with an unused reserve of 300 extra snow particles. They are unaffected by that reserve during steady-state rendering.

Native macOS, Apple M4, Godot 4.7.2, Forward+ / Metal; first 120 frames excluded, screenshot overhead included:

| Case | Mean ms | p95 ms | p99 ms | Added p95 ms |
|---|---:|---:|---:|---:|
| Effects Off, Day | 8.456 | 8.894 | 9.042 | +0.000 |
| Clear, Day | 7.047 | 9.038 | 10.722 | +0.144 |
| Snowfall, Day | 8.438 | 9.043 | 9.241 | +0.149 |
| Rain, Day | 8.431 | 9.074 | 9.193 | +0.180 |
| Rain, Night | 8.298 | 9.054 | 11.917 | +0.160 |

The final set's largest added p95 is **0.180 ms**, within the 2 ms target against current Effects Off. All five runs finish in **55.702894 s**, peak at **144.056772 km/h**, and report no crash or airtime. The exploratory variance and differing mean/p99 values show that desktop frame pacing still matters; this is an observed run comparison, not an isolated GPU-cost claim or a hardware guarantee.

Commands and evidence:

```sh
./godotw --headless --script tests/physics_suite.gd
./godotw --headless --script tests/runtime_suite.gd
./godotw --script tests/lighting_playtest.gd
./godotw -- --autoplay --weather-quality=off --benchmark-label=lighting_off
./godotw -- --autoplay --weather=clear --benchmark-label=lighting_clear
./godotw -- --autoplay --weather=snowfall --benchmark-label=lighting_snowfall
./godotw -- --autoplay --weather=rain --benchmark-label=lighting_rain
./godotw -- --autoplay --weather=rain --time-of-day=night --benchmark-label=lighting_night_rain
```

Evidence: `artifacts/lighting_results.json`, `lighting_validation.json`, `weather_benchmark_lighting_*.json`, `lighting_physics.log`, `lighting_runtime.log` and `lighting_playtest.log`. Images are `light_*.png`; visual overviews are `lighting_contact_chase.png`, `lighting_contact_pov.png` and `lighting_contact_extra.png`.

Limits: one projected cloud layer, horizon-clamped cloud projection, local geometry shadow range of 220 m, and no geometry shadows from distant decorative mountains. The orbit is artistic, without dates, seasons, lunar phases or astronomical accuracy. No terrain generation, physical weather forces, snow accumulation or wet handling was added. These observations are from one Apple M4 development machine.

## Weather and arcade effects — 2026-09-05

Implemented four presentation presets, slow automatic transitions, two GPU precipitation volumes, ground spindrift, cloud/sun lighting, a rain loop, and arcade peripheral streaks. Weather controls are available from title/pause; settings survive restart for the application session. Physics model v3, generator v2, course identity and record schema are unchanged.

### Automated and rendered acceptance

- **45/45 physics checks and 57/57 runtime checks pass.** Runtime coverage adds weather controls, three-minute holds and twenty-second blends, cycle ordering, paused/frozen progression, restart retention, quality ceilings, original-sky restoration, V/M behavior, camera-switch/teleport resets, actual HUD conditions, and unchanged simulation/record state. Autoplay now ignores live movement input and gameplay hotkeys so a focused benchmark cannot be contaminated by keyboard/controller activity.
- **35 native rendered weather captures** were inspected: Clear/Cloudy/Snowfall/Rain × chase/first person × 30/120/200 km/h entry speeds, successive snow/rain motion frames, a turn, V off, Low, Off, a blend midpoint, pause/settings layout, and restart. Every capture is unranked, with no reported camera-clearance violation. Entry speed naturally changes during each short ride (the 200 km/h fixtures reach roughly 173 km/h before the main capture); the JSON records actual speed.
- The central route, nearby obstacles, ski tips/rider, and HUD remain readable. Precipitation fills both views, persists through the full descent, changes position across successive frames, and loses exaggerated stretching with V. The weather panel fits the 1440 × 900 viewport. Cloud shapes and illumination differ between presets; fog remains an artistic distance cue rather than a whiteout.
- Native audio playback was exercised; headless checks verify wind/rain mute levels. The 7.9-second rain loop is mono 22,050 Hz PCM with measured peak 0.384 and RMS 0.120, without clipped source samples. **No subjective listening assessment is claimed.** Balance against the ski/contact layers still needs a listener. Shutdown now stops loop playback before the native audio callback is torn down; the final snow/rain benchmark logs exit without resource warnings.

### Frame-time comparison

Native macOS, Apple M4, Godot 4.7.2, Forward+ / Metal, 1440 × 900, the same full tucked descent and capture schedule. Off provides a fresh baseline using the original atmosphere and existing camera/blur effects. High is used for Clear/Snowfall/Rain. Samples exclude the first 120 warmup frames and include screenshot overhead; the shutdown wait is outside the sample window.

| Weather | Mean ms | p95 ms | p99 ms | Added p95 ms |
|---|---:|---:|---:|---:|
| Off | 8.418 | 8.449 | 8.702 | +0.000 |
| Clear | 8.409 | 8.914 | 9.354 | +0.465 |
| Snowfall | 8.420 | 9.033 | 9.734 | +0.584 |
| Rain | 8.420 | 9.167 | 9.832 | +0.718 |

The worst measured added p95 is **0.718 ms**, below the 2 ms target on this machine. All four final benchmark reports finish in **55.702894 s**, peak at **144.056772 km/h**, and report **zero airtime and no crash**. This is an observed frame-time comparison on one desktop, not an isolated GPU timing measurement or a minimum hardware guarantee.

Commands and evidence:

```sh
./godotw --headless --script tests/physics_suite.gd
./godotw --headless --script tests/runtime_suite.gd
./godotw --script tests/presentation_playtest.gd -- --weather-matrix
./godotw -- --autoplay --weather-quality=off --benchmark-label=off
./godotw -- --autoplay --weather=clear --benchmark-label=clear
./godotw -- --autoplay --weather=snowfall --benchmark-label=snowfall
./godotw -- --autoplay --weather=rain --benchmark-label=rain
```

Structured evidence: `artifacts/weather_validation.json`, `weather_benchmark_*.json`, `weather_presentation_results.json`, `physics_results.json`, and `runtime_results.json`. Native captures are `artifacts/feel_weather_*.png`; overview sheets are `weather_contact_chase.png`, `weather_contact_pov.png`, and `weather_contact_lifecycle.png`.

Limitations of this earlier pass: precipitation uses bounded periodic volumes, depth testing and soft fades, without surface collision/splashes or shelter detection. Ground drift uses two emitter-level height/normal samples and approximates uneven terrain. The later lighting pass above adds moving cloud shadows and a day/night cycle. There is no accumulation, wet grip or physical wind force. Lower-end GPUs, other operating systems, subjective audio feel and physical controllers require their own playtests.

Godot 4.7.2 stable, native macOS, Apple M4, Forward+ / Metal. The user's project rendering, plugin and autoload configuration were preserved. The editor MCP connection was unavailable, so validation used `./godotw` and screenshots from the actual rendered viewport.

## Calibration and physics

| Measurement | Previous model | Model v2 |
|---|---:|---:|
| Default tucked descent | 38.964 s | 55.703 s |
| Peak on the default descent | 193.95 km/h | 144.06 km/h |
| Contact loss on that clean line | 0 s | 0 s |
| Tucked, 20 s on a planar 24.7° slope | 172.53 km/h | 135.34 km/h |
| Upright, same plane and duration | 128.80 km/h | 91.90 km/h |

The v2 default descent reaches 30 km/h after 6.225 s, 60 after 15.358 s, 90 after 20.092 s and 120 after 25.342 s. It does not reach 150. At ten seconds the speed is 45.38 km/h. The gentler start changes the benchmark's vertical drop to approximately 600 m over 1.55 km of slope.

There is **no speed cap**. On unobstructed synthetic planes, 90-second tucked runs reach:

| Pitch | Speed |
|---|---:|
| 10° | 85.60 km/h |
| 25° | 141.75 km/h |
| 35° | 166.96 km/h |
| 55° | 201.62 km/h |

These are design calibration fixtures, not empirical validation against real ski equipment. The 55° plane is not a new playable mountain. At 200 km/h a 12° equipment-heading error leaves 71.8% balance after 0.4 s; at 90 km/h the same error remains fully recoverable. Balance depends on lateral recovery distance and available grip, not a speed threshold or random roll.

## Automated checks

- **45/45 physics checks pass.** Gravity, passivity, turning costs, braking, uphill momentum, speed calibration, stance opening, slip recovery, cross-slope heading, contact/landing/air steering, seed repeatability, swept collisions, frame-schedule independence and finish timing/width.
- **32/32 runtime checks pass.** Lifecycle, pause/resume, input strengths/bindings, exact defaults, unranked speed entry through 200 km/h, automated restart eligibility, v2 benchmark identity, first-person toggle, motion toggle, eight speed labels and viewport layout.
- **19 native rendered handling captures** cover chase and first-person views from seven lab entry speeds, a loaded turn, braking, flight, landing and the workbench. The scripted traversal reports no camera-clearance violation and every capture is unranked. Entry speeds change naturally during each capture; `presentation_results.json` records actual speed, contact, tuck and balance.

Commands:

```sh
./godotw --headless --script tests/physics_suite.gd
./godotw --headless --script tests/runtime_suite.gd
./godotw --script tests/presentation_playtest.gd
./godotw -- --autoplay
./godotw -- --autoplay --first-person
```

The two headless suites do not establish visual feel, audio quality or physical controller behavior. Native captures were inspected for skier/ski-tip visibility, readable speed labels, turn/spray feedback, camera clearance, snow/trees and workbench fit. The presentation harness manually supplies 120 Hz steps while rendering; use the complete autoplay descent for frame-time profiling.

## Rendered benchmark

The final unranked autoplay descent uses the real scene, physics and presentation at 1440 × 900. Samples use elapsed microseconds between rendered callbacks after 120 warmup frames; screenshot capture overhead is included. These numbers come from the final `artifacts/render_benchmark.json` run.

| Measurement | Result |
|---|---:|
| Captured frames | 6457 |
| Mean frame time | 8.422 ms (~118.7 FPS) |
| p95 / p99 frame time | 8.780 / 9.052 ms |
| Final smoothed simulation/session tick | 0.119 ms |
| World construction | 390.8 ms |
| Descent outcome | Finished, no crash; 0.000 s airtime |

Raw evidence: `artifacts/physics_results.json`, `runtime_results.json`, `presentation_results.json`, and `render_benchmark.json`. Native screenshots are `artifacts/run_*.png` and `artifacts/feel_*.png`.

## Limits

- Human handling acceptance and listening tests remain necessary. The audio layers and haptics are driven by the measured state, but their subjective mix and physical vibration were not verified here.
- The reference image is an art direction target. The scene remains procedural prototype art in a bounded laboratory: no photoreal assets, streamed procedural mountain, race authoring, ghosts or sharing were added.
- Tree detail switches per 128 m region at 300 m. Some LOD popping is possible. Mesh detail, nearby shadows and screen effects need profiling on lower-end GPUs.
- Contact remains a constrained point mass with a four-metre normal stencil. There are no independent flexible skis, full-body balance, active absorption or ragdoll simulation.
- Fixed-tick repeatability is checked at 30/60/120/144/240 FPS schedules on this engine. Cross-platform bitwise replays are not established.
- No physical DualShock/DualSense hardware, other desktop operating systems, packaged exports or other GPUs were tested. A development-machine measurement is not a minimum frame-rate guarantee.
- Benchmark identity is now `laboratory-v2-physics-v3-default`; old model times are not compared with this tuning. The record schema remains v1. Production records still need tuning hashes and stronger replay validation.

## Steering correction — model v3

Corrected the yaw and edge sign for rider-relative left/right. Added six physics direction checks across three starting headings and four action-to-screen direction checks covering chase and first-person views. Both suites pass without engine errors. Generator v2 and speed calibration are unchanged; the rendered benchmark above was measured in the preceding speed pass. The native handling capture was rerun after the direction fix.
