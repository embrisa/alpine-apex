# Development gates

## Current: playable movement laboratory

Milestone 1 is implemented as a prototype candidate, with initial Milestone 2 presentation. Acceptance still needs a human assessment of control and skiing feel. Automated tests measure behavior and guard against regressions; they cannot establish that skiing is fun.

Suggested first playtest:

1. Make a no-tuck run, then a tucked run. Compare braking distance and anticipation needed.
2. Compare a sequence of shallow turns to abrupt corrections; use F3 to observe slip and acceleration.
3. Use the F2 speed lab at 30, 60, 90, 120, 150, 165 and 200 km/h. Evaluate steering authority and near-object speed cues with and without instruments.
4. Take the optional right-side terrain transition around x=88 m, z=740 m and compare contact/landing behavior. A small hop on the main slope is also useful for checking landing response.
5. Repeat with a DualShock 4 and DualSense, wired and wireless where possible. Check dead zone, analog trigger range, vibration and restart mapping.

Record the speed range, input device, tuning changes and terrain location with feedback. Prioritize a controllable and rewarding high-speed carve over additional systems.

## Next: finish the speed-feel pass

- Tune steering onset, countersteering, grip saturation and small-slip energy loss through repeated player runs.
- Compare four-metre support filtering against a finer terrain/contact model; evaluate active compression absorption without adding propulsion exploits.
- Weather and arcade wind cues are implemented as presentation only. Playtest the four presets and V/quality options; listen-test the rain and gust mix alongside contact feedback.
- Listen-test the new contact/edge/landing mix, refine nearby-object rush cues, assess the lower chase/first-person cameras with V on/off, and test haptics on real hardware.
- Measure at 60/120/144+ display refresh with input capture; collect frame-time distributions on Windows/Linux and lower-end GPUs.
- Improve skier pose and snow readability only where it helps control and feedback. No excessive blur or camera shake.

## Milestone 3: actual procedural mountains

Before implementation, propose and review a versioned data contract and geological structure strategy. Build coherent peak/ridge/bowl/valley graphs, then local terrain detail and obstacle placement. Generate into background data buffers with bounded main-thread mesh upload. Keep shared collision/render sampling and add terrain LOD/streaming only when measurements justify it.

Deliver seed entry, a small set of presets, spawn selection, regeneration, named local mountain saves and load/import/export. Freeze old generation versions where feasible and reject unknown schemas safely. The existing seeded laboratory is a useful test fixture, not this system's completed implementation.

## Milestone 4: author a race in the world

Free ski → mark start → mark finish → name/save → race → instant retry. Checkpoints are optional. A lightweight race references a generator version/seed/parameters, start and finish transforms, optional gates and rules. Store schema version separately from generator and movement versions. Importers must validate finite coordinates, supported versions and practical spawn locations.

Start with local files, not online infrastructure. Share codes can encode the compact definition later. Timing can reuse swept crossing logic but should gain explicit start/finish volumes, run states and optional split events.

## Milestone 5: compete with yourself

Add tick-input recording plus sampled transforms/state, a local PB ghost, splits and visible run history. Version replay/model/tuning compatibility. Keep ghost rendering independent of current player physics and allow one-key restarts. Use replay/ghost evidence to improve the racing line before introducing network leaderboards.

The end-to-end target remains: generate → discover → create a race → race → improve → beat a best → share.

