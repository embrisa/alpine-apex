# Architecture and decisions

## Scope and identity

Alpine Apex is a high-speed downhill racing game. Preserve momentum, find a better line, and control extreme velocity. The mountain serves that loop. The prototype deliberately avoids world streaming, progression, multiplayer, and general-purpose race authoring until the movement model has been played and tuned.

The user-created Godot 4.7 project, Forward+ renderer, Jolt configuration, and MCP toolkit are preserved. The skier does not use Jolt rigid-body integration yet: a small independently testable ski solver makes the core forces easier to inspect and tune. Jolt remains available for later body/obstacle/ragdoll systems.

## Module boundaries

| Module | Responsibility |
|---|---|
| `core/rider_input.gd`, `input_router.gd` | Equipment-neutral intent: steer, tuck, brake, hop. Godot logical actions abstract hardware. |
| `core/ski_tuning.gd`, `config/ski_default.tres` | Tunable SI-unit physics and presentation values. |
| `core/ski_simulation.gd` | Rider position/velocity/heading/contact/balance, one explicit fixed step. No Nodes, audio, or rendering. |
| `world/test_slope.gd` | Shared triangulated heightfield, stable seed, obstacle spatial index, contact sampling, swept collisions. |
| `world/alpine_world.gd` | Terrain and scenery meshes, atmosphere, visual course markers. |
| `presentation/*` | Pose, camera, particles, tracks, sound and debug arrows derived from simulation state. |
| `core/run_session.gd` | Benchmark clock, within-tick finish intersection, eligibility, local PB/history persistence. |
| `ui/hud.gd` | Start/pause/finish/crash views, readable instruments and workbench. |
| `main.gd` | Wiring, lifecycle, fixed-step dispatch, presentation interpolation and automated render benchmark. |

Future snowboarding can replace the movement model and equipment pose while retaining rider intent, surface, session and presentation infrastructure. It does not require ski simulation inheritance.

## Ski model

The skier is currently a **constrained point mass with equipment orientation**, not a full articulated body or a physically complete ski/snow simulation. Acceleration is measured in m/s²; mass divides out of gravity, drag coefficients and normalized contact forces. HUD friction and normal load are therefore acceleration / multiples of g, not Newtons.

1. Input changes the skis' horizontal heading at a speed-dependent angular rate. Steering intent is negative for rider-left and positive for rider-right. With forward `(sin(heading), 0, cos(heading))`, rider-right is `forward.cross(UP)`, so positive steering decreases heading and targets a negative edge angle (model v3 correction). It never sets velocity. The tangent's vertical component is solved from the surface normal so a cross-slope does not silently change the player's selected horizontal azimuth.
2. Gravity projected onto the contact plane provides slope acceleration. Alignment and terrain determine how much gravity acts along the velocity. There is no racing-line attraction or speed cap.
3. Lateral grip opposes sideways velocity. Edge angle raises available lateral grip; the impulse is capped by estimated normal load and by the impulse needed to remove slip. Grip never adds kinetic energy. Gradual carving dissipates little; abrupt direction changes create slip and lose speed.
4. Surface friction, edge-dependent resistance, skidding friction, braking and quadratic aerodynamic drag dissipate momentum. Model v2 uses upright drag 0.0058 1/m and a deep-tuck ratio of 0.43. Effective tuck settles over time; turning and braking open the stance. A deep tuck reduces grip leverage to 76% and slows edge engagement, so maintaining speed has a control cost. Tucking changes resistance, not gravity or propulsion.
5. Estimated normal acceleration is `-velocity · d(normal)/dt`. The support force is that acceleration minus gravity's normal component. A negative required support releases the skier because snow cannot pull the skier downward.
6. In the air, gravity and aerodynamic drag act on velocity. Input may orient the equipment but cannot redirect its trajectory. Landing uses a swept heightfield intersection and the velocity component into the surface. Hard normal impacts or bad alignment destabilize/crash the rider.
7. Rocks and tree trunks use swept horizontal collision tests with vertical bounds and spatial hashing. This prevents high-speed tunneling through thin obstacles. Lateral recovery distance is estimated as sideways speed squared divided by twice available grip acceleration. Exceeding 2.5 m of recovery room drains balance; the drain is bounded at 2/s with 0.3/s recovery so a full-balance rider gets at least about 0.59 s to respond. Clean alignment never receives a speed-triggered failure. These are gameplay stability approximations, not a full-body balance solver.

**Airtime nuance:** gravity still accelerates a skier while airborne, and horizontal momentum receives less snow drag. It would be physically incorrect to turn gravity off in the air. There is no airborne *slope-contact acceleration* or lateral grip. The tests enforce that separation. Terrain and landing penalties must make excessive airtime costly; this remains an explicit tuning target rather than a claim that flight is always slower.

### Contact approximation and risks

Collision heights use the same triangle diagonal and barycentric interpolation as the rendered 4 m grid. Support normals use a four-metre finite-difference stencil: a coarse-grid suspension approximation that prevents a triangle seam from behaving like a sharp physical crest. This is not a literal four-metre ski, nor a complete suspension model.

Velocity projection onto a changing contact plane is passive and can lose energy. It does not model a perfect energy-preserving curved constraint. Contact loads and landing tolerance are deliberately inspectable. Validate energy, contact duration, stability and route times before making terrain rougher or refining grid resolution.

There is no independent per-ski pressure distribution, active absorption/pumping, torsional ski flex, body angular momentum, or physical ragdoll yet. Tuck provides a small landing tolerance benefit but does not fake adhesion to convex terrain. These are potential movement experiments, not prerequisites for a first playtest.

### Speed calibration, model/generator v2

The authored launch apron is approximately 10°, blending smoothly into the 25° race face over z=80–340 m. The height profile integrates the pitch transition to avoid a contact discontinuity. The clear obstacle corridor narrows from 36 to 15 m half-width; all added proximity comes from the same seeded, collidable trees and rocks. The normal stencil and contact solver remain shared with the rendered heightfield.

The intended bands are 0–30 maneuvering, 30–60 ordinary skiing, 60–90 fast, 90–120 racing, 120–150 elite downhill, 150–165 extreme racing, 165–200 extreme terrain, and 200+ exceptional speed. These are HUD/design descriptions; they do not clamp velocity. On ideal planar pitches, 90 s tucked runs settle around 86 km/h at 10°, 142 at 25°, 167 at 35°, and 202 at 55°. The last is an exceptional synthetic test pitch, not a claim of a playable speed-skiing mountain in this laboratory.

## Timing and determinism

Godot dispatches `_physics_process` at 120 Hz. The renderer interpolates the previous and current completed positions and cannot change the solver's time step. Input is sampled per physics tick; accumulated OS input is disabled. Pose/camera use render-time smoothing. Translational camera follow is immediate so high speed cannot make the camera recede indefinitely. Maximum catch-up steps are bounded at 24; under severe overload the engine can slow simulated time rather than silently discard meaningful input history.

Godot documents the latency tradeoff of interpolation and high tick rates in [its interpolation introduction](https://docs.godotengine.org/en/stable/tutorials/physics/interpolation/physics_interpolation_introduction.html). Our positional interpolation introduces up to one 120 Hz tick (~8.33 ms), not a display-frame-dependent physics rate.

The local tests verify repeatability for identical tick inputs under 30, 60, 120, 144 and 240 FPS frame schedules. **Cross-platform bitwise deterministic replays are not promised.** Float arithmetic, engine/noise changes and input sampling time can change results. Future competitive replays should version engine/generator/model/tuning and include periodic state snapshots or authoritative validation.

Race time accumulates simulation steps, not rendered-frame time. A finish-plane intersection adds only the crossed fraction of the last tick. Millisecond formatting is backed by sub-tick interpolation, not merely additional decimal places. Pausing excludes time. The benchmark has a 72 m wide finish plane; it is not a mandatory checkpoint course.

Local record schema v1 includes course identity, best time and the last 20 eligible runs. Course identity includes generator and physics versions. Modified workbench and speed-lab runs cannot set records. The file is `user://benchmark_v1.json`; normal Godot user-data paths apply. A production system also needs tuning hashes, stronger schema validation, tamper handling and replay metadata.

## Rendering and performance

The laboratory uses 96 terrain chunks and 196,608 terrain triangles, with modest distant ridge meshes. Vegetation shares meshes via MultiMeshes grouped into 128 m regions with distance culling. Snow-covered branch meshes switch to a simpler shared mesh at 300 m; distant trees stop casting shadows. The region-level switch is intentionally inexpensive and can produce some visible LOD popping. There are no per-tree Node or rigid-body updates. See [Godot's MultiMesh reference](https://docs.godotengine.org/en/stable/classes/class_multimesh.html) for the shared-instance rendering approach.

The two spray emitters have a fixed 380-particle ceiling. Tracks use an 800-instance ring buffer. Wind/ski audio uses precomputed short PCM loops, avoiding GDScript sample synthesis in the frame loop. HUD telemetry updates at 10 Hz; the speed and timer instruments remain immediate. A compact arc instrument labels all eight speed bands, with a separate balance indicator. It displays the full velocity magnitude in km/h, including while airborne.

The chase boom is lower and closer to keep local snow in view. C toggles first person using the same ski geometry with the rider body hidden. Camera bank follows measured lateral acceleration; compression follows normal load and landing speed. Travel-based chatter is small, bounded, and absent in flight. Dynamic FOV and a five-sample peripheral screen blur build progressively; the center remains clear. V disables FOV modulation, bank, compression, chatter and peripheral blur. Audio uses separate wind, running-ski and edge-scrape layers, with contact/landing/edge-load mixing. Haptic output is bounded and cleared on pause/exit, but requires hardware assessment.

### Weather presentation

`presentation/weather_controller.gd` owns the four configurable resources in `config/weather/`, the 180-second hold / 20-second blend cycle, and one shared `WeatherState`. The cycle is clear → cloudy → snowfall → cloudy → rain → cloudy. The controller uses presentation time, advances the cycle only while skiing, and retains progression across restart. Title ambience animates without advancing the automatic cycle. Disabling automatic mode holds the current blend; explicitly selecting a preset begins a fresh hold. Selection and quality are application-session settings.

Main supplies presentation state and camera movement. The world consumes lighting, cloud, and fog values; weather effects consume wind and precipitation; the existing audio mixer consumes gust/rain values; the HUD displays actual weather. Weather never enters `SkiSimulation`, gameplay input sampling, terrain generation, timing, record eligibility, or course identity. The autoplay harness now uses only fixed tuck input and ignores gameplay hotkeys, preventing live keyboard/controller activity from contaminating benchmark comparisons. No benchmark version bump is needed for this cosmetic addition.

The sky computes three simple noise octaves in a half-resolution pass. A cheap cloud-free cubemap branch keeps realtime radiance work bounded; Godot Forward+ fixes realtime radiance at 256. Cloud offsets integrate wind displacement in world metres, preventing jumps during gusts or preset transitions. Off uses the original procedural sky and clear atmosphere at the selected time, and disables cloud attenuation.

`presentation/cloud_lighting.gd` owns a per-world registry shared by snow, skier, tracks, rocks, trees, markers, and the sky. `cloud_field.gdshaderinc` projects sky rays and direct-light receiver rays onto the same horizontal cloud layer at world Y = 2,400 m. The same wind offset and coverage drive both projections, so moving clouds shade the player and terrain together. `cloud_light.gdshaderinc` applies that transmission to directional light only, retaining Godot's object-shadow attenuation and ambient fill. Opaque surface shaders use Burley diffuse and GGX specular; they continue to cast geometry shadows. Nearby terrain now casts shadows as well as receiving them. This follows Godot's [custom spatial light processing](https://docs.godotengine.org/en/stable/tutorials/shaders/shader_reference/spatial_shader.html#light-built-ins); the shared cloud field adds no lights or shadow-map passes.

`presentation/daylight_cycle.gd` applies an artistic winter sun orbit after weather blending. Dawn, Day, Dusk and Night select 06:30, 12:00, 17:30 and 00:00. The optional cycle takes 1,200 seconds of active skiing, independently of automatic weather, and retains its hour through restart. Both clocks stop on title/pause/finish. Noon preserves the original 24-degree solar elevation; dawn/dusk warm and weaken the sun. A separate moon light fades in at night. Their active ranges do not overlap, keeping one directional shadow map active. Weather modifies direct-light strength and tint, while sky, clouds, ambient fill and fog blend through twilight. Main supplies camera/lifecycle state; the HUD exposes selection and cycle controls and displays the current time band. This does not use wall-clock time or change solver state.

Cloud transmission is sampled per mesh vertex and interpolated across surfaces. Terrain vertices are spaced four metres apart, fine enough for the broad cloud patches; the sky retains its half-resolution noise pass. This removes repeated cloud-noise work from every surface pixel while keeping object-shadow attenuation and material response per pixel. The surface projection uses the active upper-hemisphere direction (sun by day, moon at night). Additional directional lights would need their own projection contract. Coarse distant decorative meshes approximate cloud edges more loosely than the player and local terrain.

Two GPU precipitation fields allocate 600 snow particles and 900 rain particles on High, with two 100-particle ground emitters: 1,700 total, below the 2,000-particle ceiling even across transitions. Low allocates half as many (850, below its 1,000 ceiling). The snow allocation was reduced during lighting profiling. Precipitation uses translation-only local volumes, world wind/fall velocity minus actual camera translation velocity exactly once, periodic wrapping, and retained particle data across emission lifetimes. New volumes fill immediately. Teleports, camera changes, restarts, and quality changes reset presentation history. Ground emitters sample terrain twice per render update; no CPU per-particle terrain queries, physics collision, or particle Nodes are created.

Snow and rain retain depth testing and fade near the camera, at the volume boundary, and through the central route region. Arcade streaks share the existing peripheral shader and render below the HUD. Camera motion intensity drives bounded stretching, beginning at 60 km/h and approaching full intensity at 200 km/h. Inactive gameplay removes speed accents immediately. V also disables the new streaks and exaggerated precipitation stretching; M fades every audio layer to silence. Rain uses a precomputed mono PCM loop generated by `scripts/tools/generate_rain_audio.py` rather than frame-loop synthesis.

Weather remains an artistic approximation: no precipitation collision/splashes, accumulation, wet materials/grip, physically occluded wind, or physical wind forces. Clouds use one projected layer rather than volumetric geometry. Their shadow projection clamps near the horizon while direct light fades. Distant decorative mountains receive lighting but do not cast geometry shadows; local directional shadows are bounded to 220 m. The sun/moon orbit does not model latitude, seasons, dates or lunar phases. Headless tests cannot establish subjective audio mix, visual feel, or device performance.

Large transparent particles, long-range vegetation shadows and terrain expansion are the main rendering risks. The current static scene is deliberately small enough to profile without streaming. Building it synchronously costs roughly 0.4–0.5 s on the development machine; future generated mountains need background data generation and mesh upload budgets. No terrain LOD/streaming implementation is claimed yet.

Godot's [controller documentation](https://docs.godotengine.org/en/stable/tutorials/inputs/controllers_gamepads_joysticks.html) describes the SDL-backed standard input model. PlayStation names appear only in user-facing guidance; simulation input is controller-model independent. Trigger/stick mapping is tested at the action layer. Physical devices, trigger calibration and vibration still need hardware playtests.
