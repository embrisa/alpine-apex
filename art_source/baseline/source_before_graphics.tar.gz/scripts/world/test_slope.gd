extends RefCounted
## Generator v2 is a deliberately authored laboratory valley, not yet the
## mountain generator. Seed only varies small landforms and scenery.
const GENERATOR_VERSION = 2
const CELL = 4.0
const X_MIN = -384.0
const Z_MIN = -192.0
const NX = 193
const NZ = 513
const SPATIAL_CELL = 48.0
var seed_value: int = 849205174
var heights: PackedFloat32Array
var obstacles: Array = []
var obstacle_grid: Dictionary = {}
var noise = FastNoiseLite.new()

func _init(mountain_seed: int = 849205174) -> void:
	seed_value = mountain_seed
	noise.seed = seed_value
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 0.009
	noise.fractal_octaves = 3
	heights.resize(NX * NZ)
	for z in range(NZ):
		for x in range(NX):
			var wx = X_MIN + x * CELL
			var wz = Z_MIN + z * CELL
			heights[z * NX + x] = _landform(wx, wz)
	_scatter()

func _landform(x: float, z: float) -> float:
	var channel = 14.0 * sin(z * 0.0027)
	var cross = absf(x - channel)
	var shoulder = pow(cross / 115.0, 1.6) * 26.0
	var roughness = lerpf(0.7, 23.0, smoothstep(35.0, 245.0, cross))
	var waves = sin(z * 0.009) * 4.0 + sin(z * 0.019 + x * 0.009) * 1.5
	var training_flat = smoothstep(85.0, 200.0, z)
	# Broad compression and convex transition, followed by an optional sharp
	# right-side lip. The fall-line corridor remains approachable at low speed.
	var roller = 8.0 * exp(-pow((z - 670.0) / 62.0, 2.0))
	var side_drop = 16.0 * exp(-pow((x - 88.0) / 36.0, 2.0)) * tanh((740.0 - z) / 14.0)
	# Integrate a smooth pitch transition: 10° apron, then a 25° race face.
	# Changing gravity would make every slope floaty; the terrain earns speed.
	var ramp_length = 260.0
	var u = clampf((z - 80.0) / ramp_length, 0.0, 1.0)
	var pitch_integral = ramp_length * (u * u * u - 0.5 * u * u * u * u) + maxf(0.0, z - 340.0)
	return 1370.0 - z * 0.18 - 0.28 * pitch_integral + shoulder + (waves + roller + side_drop + noise.get_noise_2d(x, z) * roughness) * training_flat

func vertex(ix: int, iz: int) -> Vector3:
	return Vector3(X_MIN + ix * CELL, heights[iz * NX + ix], Z_MIN + iz * CELL)

func sample(x: float, z: float) -> Dictionary:
	var gx = clampf((x - X_MIN) / CELL, 0.0, NX - 1.001)
	var gz = clampf((z - Z_MIN) / CELL, 0.0, NZ - 1.001)
	var ix = int(gx)
	var iz = int(gz)
	var u = gx - ix
	var v = gz - iz
	var h00 = heights[iz * NX + ix]
	var h10 = heights[iz * NX + ix + 1]
	var h01 = heights[(iz + 1) * NX + ix]
	var h11 = heights[(iz + 1) * NX + ix + 1]
	var h: float
	var dx: float
	var dz: float
	# Exact barycentric height on the same diagonal as the rendered triangles.
	if u + v <= 1.0:
		dx = (h10 - h00) / CELL
		dz = (h01 - h00) / CELL
		h = h00 + u * (h10 - h00) + v * (h01 - h00)
	else:
		dx = (h11 - h01) / CELL
		dz = (h11 - h10) / CELL
		h = h11 + (1.0 - u) * (h01 - h11) + (1.0 - v) * (h10 - h11)
	return {"height": h, "normal": Vector3(-dx, 1.0, -dz).normalized()}

func spawn_point() -> Vector3:
	return Vector3(0.0, sample(0.0, 25.0).height, 25.0)

func contact_normal(x: float, z: float) -> Vector3:
	# A four-metre support stencil filters the 4 m mesh's normal discontinuities.
	# This is a coarse-grid suspension approximation, not a rigid four-metre ski.
	# Height collision remains exact; this supplies distributed ski support.
	var dx: float = sample(x + 2.0,z).height - sample(x - 2.0,z).height
	var dz: float = sample(x,z + 2.0).height - sample(x,z - 2.0).height
	return Vector3(-dx,4.0,-dz).normalized()

func _scatter() -> void:
	var rng = RandomNumberGenerator.new()
	rng.seed = seed_value
	for i in range(1450):
		var x = rng.randf_range(-330.0, 330.0)
		var z = rng.randf_range(75.0, 1780.0)
		# A safe starting apron; progressively closer obstacles communicate pace.
		var corridor = lerpf(36.0, 15.0, smoothstep(120.0, 650.0, z))
		if absf(x) < corridor or (z < 450.0 and absf(x) > 240.0):
			continue
		var tree = rng.randf() > 0.14
		var scale_value = rng.randf_range(0.65, 1.65) if tree else rng.randf_range(0.8, 3.3)
		var radius = 0.46 * scale_value if tree else 1.35 * scale_value
		var obstacle = {"position": Vector3(x, sample(x, z).height, z), "radius": radius, "height": 11.0 * scale_value if tree else 2.0 * scale_value, "scale": scale_value, "yaw": rng.randf_range(-PI, PI), "tree": tree}
		var idx = obstacles.size()
		obstacles.append(obstacle)
		# Insert radius-expanded bounds; sweeping the rider queries crossed cells.
		for gz in range(floori((z - radius) / SPATIAL_CELL), floori((z + radius) / SPATIAL_CELL) + 1):
			for gx in range(floori((x - radius) / SPATIAL_CELL), floori((x + radius) / SPATIAL_CELL) + 1):
				var key = Vector2i(gx, gz)
				if not obstacle_grid.has(key):
					obstacle_grid[key] = []
				obstacle_grid[key].append(idx)

func sweep_obstacle(from: Vector3, to: Vector3) -> String:
	if absf(to.x) > 375.0 or to.z < -170.0 or to.z > 1820.0:
		return "OUT OF TEST AREA"
	var a = Vector2(from.x, from.z)
	var b = Vector2(to.x, to.z)
	var delta = b - a
	var denom = maxf(delta.length_squared(), 0.000001)
	var checked: Dictionary = {}
	for gz in range(floori((minf(a.y, b.y) - 0.4) / SPATIAL_CELL), floori((maxf(a.y, b.y) + 0.4) / SPATIAL_CELL) + 1):
		for gx in range(floori((minf(a.x, b.x) - 0.4) / SPATIAL_CELL), floori((maxf(a.x, b.x) + 0.4) / SPATIAL_CELL) + 1):
			for idx in obstacle_grid.get(Vector2i(gx, gz), []):
				if checked.has(idx):
					continue
				checked[idx] = true
				var ob = obstacles[idx]
				var p: Vector3 = ob.position
				var t = clampf((Vector2(p.x, p.z) - a).dot(delta) / denom, 0.0, 1.0)
				var nearest = a + delta * t
				if nearest.distance_squared_to(Vector2(p.x, p.z)) < pow(ob.radius + 0.35, 2.0):
					var h = lerpf(from.y, to.y, t)
					if h < p.y + ob.height and h + 1.6 > p.y:
						return "TREE IMPACT" if ob.tree else "ROCK IMPACT"
	return ""
