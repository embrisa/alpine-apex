extends Node3D
## Small static laboratory: shared terrain grid, culled chunks and spatially
## grouped MultiMeshes. No per-tree Nodes, physics bodies, or per-frame allocation.
var surface
var snow_material: ShaderMaterial
var generation_ms: float = 0.0
var terrain_triangles: int = 0
var environment: Environment
var sun: DirectionalLight3D
var moon: DirectionalLight3D
var original_sky: Sky
var weather_sky: Sky
var weather_material: ShaderMaterial
var cloud_offset = Vector2.ZERO
const CloudLighting = preload("res://scripts/presentation/cloud_lighting.gd")
var cloud_lighting = CloudLighting.new()

func build(field) -> void:
	var start = Time.get_ticks_usec()
	surface = field
	snow_material = ShaderMaterial.new()
	snow_material.shader = preload("res://assets/snow.gdshader")
	snow_material.set_shader_parameter("material_specular",0.24)
	cloud_lighting.register(snow_material)
	_environment()
	_terrain()
	_vistas()
	_vegetation()
	_course_markers()
	generation_ms = (Time.get_ticks_usec() - start) / 1000.0

func _environment() -> void:
	var world = WorldEnvironment.new()
	var env = Environment.new()
	environment = env
	var sky = Sky.new()
	var material = ProceduralSkyMaterial.new()
	material.sky_top_color = Color("456b91")
	material.sky_horizon_color = Color("d7cfc5")
	material.ground_bottom_color = Color("637f98")
	material.ground_horizon_color = Color("b4d0e2")
	material.sky_curve = 0.22
	material.sun_angle_max = 5.0
	sky.sky_material = material
	original_sky = sky
	weather_material = ShaderMaterial.new()
	weather_material.shader = preload("res://assets/weather_sky.gdshader")
	weather_sky = Sky.new()
	weather_sky.sky_material = weather_material
	weather_sky.process_mode = Sky.PROCESS_MODE_REALTIME
	# Realtime radiance is fixed at 256 by the Forward+ renderer.
	weather_sky.radiance_size = Sky.RADIANCE_SIZE_256
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("abc5e1")
	env.ambient_light_energy = 0.32
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color("aab8cb")
	env.fog_light_energy = 0.75
	env.fog_density = 0.00012
	world.environment = env
	add_child(world)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-24.0, -58.0, 0.0)
	sun.light_color = Color("ffe1bb")
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 220.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.shadow_bias = 0.035
	add_child(sun)
	moon = DirectionalLight3D.new()
	moon.name = "Moonlight"
	moon.light_energy = 0.0
	moon.visible = false
	moon.shadow_enabled = true
	moon.directional_shadow_max_distance = 220.0
	moon.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	moon.shadow_bias = sun.shadow_bias
	add_child(moon)
	cloud_lighting.register(weather_material)

func update_weather(state, dt: float, animate: bool) -> void:
	environment.sky = weather_sky if state.enabled else original_sky
	sun.light_color = state.sun_color
	sun.light_energy = state.sun_energy
	sun.basis = Basis.looking_at(-state.sun_direction,Vector3.UP)
	sun.visible = state.sun_energy>0.001
	moon.basis = Basis.looking_at(state.sun_direction,Vector3.UP)
	moon.light_color = state.moon_color
	moon.light_energy = state.moon_energy
	moon.visible = state.moon_energy>0.001
	environment.ambient_light_color = state.ambient_color
	environment.ambient_light_energy = state.ambient_energy
	environment.fog_light_color = state.fog_color
	environment.fog_density = state.fog_density
	environment.fog_sky_affect = 0.25 if state.enabled else 1.0
	# Integrate displacement instead of multiplying time by changing wind:
	# a gust or transition must not teleport the clouds.
	if animate and state.enabled:
		cloud_offset += Vector2(state.wind_velocity.x,state.wind_velocity.z)*dt
	cloud_lighting.update(state,cloud_offset,state.sun_direction)
	var camera = get_viewport().get_camera_3d()
	if camera:
		weather_material.set_shader_parameter("cloud_camera_position",camera.global_position)
	if not state.enabled:
		var clear_material: ProceduralSkyMaterial = original_sky.sky_material
		clear_material.sky_top_color = state.sky_top
		clear_material.sky_horizon_color = state.sky_horizon
		clear_material.ground_horizon_color = state.fog_color
		clear_material.ground_bottom_color = state.sky_top
		return
	for key in ["sky_top","sky_horizon","cloud_color","sun_color"]:
		weather_material.set_shader_parameter(key,state.get(key))
	weather_material.set_shader_parameter("sun_glow_strength",smoothstep(0.0,0.16,state.sun_direction.y))
	weather_material.set_shader_parameter("moon_glow_strength",smoothstep(0.01,0.20,-state.sun_direction.y))

func _terrain() -> void:
	var chunk = 32
	for cz in range(0, surface.NZ - 1, chunk):
		for cx in range(0, surface.NX - 1, chunk):
			var nx = mini(chunk, surface.NX - 1 - cx)
			var nz = mini(chunk, surface.NZ - 1 - cz)
			var vertices = PackedVector3Array()
			var normals = PackedVector3Array()
			var indices = PackedInt32Array()
			for z in range(nz + 1):
				for x in range(nx + 1):
					var p = surface.vertex(cx + x, cz + z)
					vertices.append(p)
					# Central differences smooth shading only; contact uses exact faces.
					var dx = surface.sample(p.x + 2, p.z).height - surface.sample(p.x - 2, p.z).height
					var dz = surface.sample(p.x, p.z + 2).height - surface.sample(p.x, p.z - 2).height
					normals.append(Vector3(-dx, 4.0, -dz).normalized())
			for z in range(nz):
				for x in range(nx):
					var a = z * (nx + 1) + x
					var b = a + 1
					var c = a + nx + 1
					var d = c + 1
					indices.append_array(PackedInt32Array([a,b,c,b,d,c]))
			var arrays = []
			arrays.resize(Mesh.ARRAY_MAX)
			arrays[Mesh.ARRAY_VERTEX] = vertices
			arrays[Mesh.ARRAY_NORMAL] = normals
			arrays[Mesh.ARRAY_INDEX] = indices
			var mesh = ArrayMesh.new()
			mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
			var instance = MeshInstance3D.new()
			instance.mesh = mesh
			instance.material_override = snow_material
			instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
			add_child(instance)
			terrain_triangles += indices.size() / 3

func _vistas() -> void:
	var rng = RandomNumberGenerator.new()
	rng.seed = surface.seed_value + 42
	# Distant faceted ridges are presentation only, outside the bounded test area.
	for side in [-1, 1]:
		for j in range(5):
			var origin = Vector3(side * rng.randf_range(750, 1550), 450 - j * 80, j * 900 - 300)
			_mountain(origin, rng.randf_range(650, 1100), rng.randf_range(1000, 1650), rng.randi())
	for j in range(5):
		_mountain(Vector3((j - 2) * 1100, -80, 4200 + (j % 2) * 700), 1050, rng.randf_range(1550, 2350), rng.randi())

func _mountain(origin: Vector3, radius: float, elevation: float, seed_value: int) -> void:
	var noise = FastNoiseLite.new()
	noise.seed = seed_value
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 0.0016
	noise.fractal_octaves = 2
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var resolution = 48
	var points = PackedVector3Array()
	for z in range(resolution + 1):
		for x in range(resolution + 1):
			var px = (float(x) / resolution * 2.0 - 1.0) * radius
			var pz = (float(z) / resolution * 2.0 - 1.0) * radius
			var dist = Vector2(px, pz * 0.83).length() / radius
			var ridge = absf(noise.get_noise_2d(px + origin.x, pz + origin.z))
			var ribs = sin(atan2(pz,px)*7.0+origin.x)*0.10
			var h = pow(maxf(0.0, 1.0 - dist), 1.15) * elevation * (0.75 + ridge * 0.48 + ribs)
			points.append(Vector3(px, h, pz))
	for z in range(resolution):
		for x in range(resolution):
			var a = z * (resolution + 1) + x
			for idx in [a, a + 1, a + resolution + 1, a + 1, a + resolution + 2, a + resolution + 1]:
				st.add_vertex(points[idx])
	st.generate_normals()
	st.index()
	var instance = MeshInstance3D.new()
	instance.mesh = st.commit()
	instance.position = origin
	instance.material_override = snow_material
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)

func _pine_mesh(detailed: bool = true) -> ArrayMesh:
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rng = RandomNumberGenerator.new()
	rng.seed = 72041
	# One shared branch mesh, instanced by region. Broken, drooping whorls
	# leave dark gaps under snow shelves instead of stacked solid cones.
	for side in range(7):
		var a = side * TAU / 7.0
		var b = (side + 1) * TAU / 7.0
		_pine_face(st,Vector3(cos(a)*0.20,0,sin(a)*0.20),Vector3(0,10.3,0),Vector3(cos(b)*0.20,0,sin(b)*0.20),Color("4c4139"))
	var levels = 12 if detailed else 7
	var branches = 7 if detailed else 5
	var tufts = 2 if detailed else 1
	for level in range(levels):
		var y = 1.1 + level * (8.4 / levels)
		var radius = 2.8 * pow(1.0 - y / 10.7,0.8)
		var phase = level * 2.39
		for branch in range(branches):
			var angle = phase + branch * TAU / branches + rng.randf_range(-0.14,0.14)
			var outward = Vector3(cos(angle),0,sin(angle))
			var across = Vector3(-sin(angle),0,cos(angle))
			var reach = radius * rng.randf_range(0.76,1.13)
			var origin = Vector3(0,y,0)
			for tuft in range(tufts):
				var t = 0.40 + tuft * 0.40 if detailed else 0.62
				var center = origin + outward * reach * t - Vector3.UP * (t * 0.37)
				var width = reach * (0.34 - tuft * 0.08)
				var back = center - outward * reach * 0.24
				var tip = center + outward * reach * 0.32 - Vector3.UP * 0.16
				var crown = center + Vector3.UP * (0.30 + reach * 0.13)
				var left = back - across * width
				var right = back + across * width
				var green = Color("253d3e").lightened(rng.randf_range(0.0,0.12))
				_pine_face(st,left,crown,tip,green)
				_pine_face(st,tip,crown,right,green)
				_pine_face(st,right,crown,left,green)
				# Small irregular snow caps reveal the needles around each edge.
				var snow = Color("d4dde0").lightened(rng.randf_range(0.0,0.07))
				var snowy_tip = tip.lerp(crown,0.24) + Vector3.UP*0.035
				var snowy_left = left.lerp(crown,0.23) + Vector3.UP*0.035
				var snowy_right = right.lerp(crown,0.23) + Vector3.UP*0.035
				var snowy_top = crown + Vector3.UP*0.05
				_pine_face(st,snowy_left,snowy_top,snowy_tip,snow)
				_pine_face(st,snowy_tip,snowy_top,snowy_right,snow)
	st.generate_normals()
	st.index()
	var mesh = st.commit()
	var mat = cloud_lighting.material(Color.WHITE,0.95,true)
	mesh.surface_set_material(0, mat)
	return mesh

func _pine_face(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, color: Color) -> void:
	st.set_color(color)
	st.add_vertex(a)
	st.add_vertex(b)
	st.add_vertex(c)

func _vegetation() -> void:
	var pine = _pine_mesh()
	var distant_pine = _pine_mesh(false)
	var stone = SphereMesh.new()
	stone.radius = 1.4
	stone.height = 2.5
	stone.radial_segments = 7
	stone.rings = 3
	var stone_mat = cloud_lighting.material(Color("667781"),0.97)
	stone.material = stone_mat
	var groups: Dictionary = {}
	for ob in surface.obstacles:
		var key = "%d_%d_%s" % [floori(ob.position.x / 128.0), floori(ob.position.z / 128.0), str(ob.tree)]
		if not groups.has(key):
			groups[key] = []
		groups[key].append(ob)
	for key in groups:
		var objects = groups[key]
		var mm = MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = pine if objects[0].tree else stone
		mm.instance_count = objects.size()
		for i in range(objects.size()):
			var ob = objects[i]
			var basis_value = Basis(Vector3.UP, ob.yaw).scaled(Vector3.ONE * ob.scale)
			var pos: Vector3 = ob.position + (Vector3.ZERO if ob.tree else Vector3.UP * ob.scale * 0.7)
			mm.set_instance_transform(i, Transform3D(basis_value, pos))
		var instance = MultiMeshInstance3D.new()
		instance.multimesh = mm
		instance.visibility_range_end = 1150.0
		instance.visibility_range_end_margin = 120.0
		add_child(instance)
		if objects[0].tree:
			instance.visibility_range_end = 300.0
			instance.visibility_range_end_margin = 0.0
			var distant = MultiMeshInstance3D.new()
			var distant_mm = MultiMesh.new()
			distant_mm.transform_format = MultiMesh.TRANSFORM_3D
			distant_mm.mesh = distant_pine
			distant_mm.instance_count = mm.instance_count
			for i in range(mm.instance_count):
				distant_mm.set_instance_transform(i,mm.get_instance_transform(i))
			distant.multimesh = distant_mm
			distant.visibility_range_begin = 300.0
			distant.visibility_range_end = 1150.0
			distant.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(distant)

func material(color: Color, emission: bool = false) -> ShaderMaterial:
	return cloud_lighting.material(color,0.7,false,emission)

func box(pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var mesh = BoxMesh.new()
	mesh.size = size
	var node = MeshInstance3D.new()
	node.mesh = mesh
	node.position = pos
	node.material_override = material(color)
	add_child(node)
	return node

func _course_markers() -> void:
	_gate(5.0, 6.0, "APEX  /  DROP IN", false)
	_gate(1450.0, 36.0, "FINISH", true)
	for z in range(125, 1450, 125):
		for side in [-1, 1]:
			var x = side * 37.0
			var h = surface.sample(x, z).height
			box(Vector3(x, h + 1.25, z), Vector3(0.10, 2.5, 0.10), Color("253f4d"))
			box(Vector3(x, h + 2.3, z), Vector3(0.38, 0.45, 0.09), Color("c6eb68"))
		if z % 250 == 0:
			var label = Label3D.new()
			label.text = "%d m" % (1450 - z)
			label.font_size = 52
			label.pixel_size = 0.022
			label.position = Vector3(41, surface.sample(41, z).height + 4.0, z)
			label.rotation.y = PI
			label.modulate = Color("203e4c")
			add_child(label)

func _gate(z: float, width: float, title: String, finish: bool) -> void:
	var center_h = surface.sample(0, z).height
	var height_value = 8.0 if finish else 6.0
	for side in [-1, 1]:
		var x = side * width
		var h = surface.sample(x, z).height
		box(Vector3(x, h + height_value / 2, z), Vector3(0.42, height_value, 0.42), Color("163441"))
		box(Vector3(x, h + 1.0, z), Vector3(0.6, 2.0, 0.6), Color("c4ea5e"))
	box(Vector3(0, center_h + height_value, z), Vector3(width * 2 + 0.5, 1.3, 0.42), Color("163441"))
	var label = Label3D.new()
	label.text = title
	label.font_size = 96
	label.pixel_size = 0.011 if not finish else 0.035
	label.position = Vector3(0, center_h + height_value, z - 0.24)
	label.rotation.y = PI
	label.modulate = Color("eaf1ef")
	label.outline_size = 0
	add_child(label)
