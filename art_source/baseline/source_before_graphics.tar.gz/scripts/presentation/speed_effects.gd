extends Node3D
## Fixed-size effects. Presentation randomness never enters the simulation.
var sprays: Array = []
var tracks: MultiMesh
var track_cursor: int = 0
var last_track = Vector3.INF
var audio_wind: AudioStreamPlayer
var audio_ski: AudioStreamPlayer
var muted: bool = false
var haptic_clock: float = 0.0
var audio_edge: AudioStreamPlayer
var audio_rain: AudioStreamPlayer
var lighting = preload("res://scripts/presentation/cloud_lighting.gd").new()

func _exit_tree() -> void:
	stop_audio()
	for pad in Input.get_connected_joypads():
		Input.stop_joy_vibration(pad)

func stop_audio() -> void:
	for player in [audio_wind,audio_ski,audio_edge,audio_rain]:
		if is_instance_valid(player):
			player.stop()
			player.stream = null

func _ready() -> void:
	for side in [-1, 1]:
		var spray = GPUParticles3D.new()
		spray.amount = 190
		spray.lifetime = 0.68
		spray.explosiveness = 0.0
		spray.local_coords = false
		spray.visibility_aabb = AABB(Vector3(-20,-12,-20), Vector3(40,24,40))
		var process = ParticleProcessMaterial.new()
		process.direction = Vector3(side * 0.38, 0.65, -0.75)
		process.spread = 26.0
		process.initial_velocity_min = 1.0
		process.initial_velocity_max = 3.2
		process.gravity = Vector3(0,-3.5,0)
		process.scale_min = 0.025
		process.scale_max = 0.09
		process.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
		process.emission_box_extents = Vector3(0.05,0.02,0.55)
		var gradient = Gradient.new()
		gradient.set_color(0, Color(0.88,0.95,1,0.68))
		gradient.set_color(1, Color(0.88,0.95,1,0))
		var texture = GradientTexture1D.new()
		texture.gradient = gradient
		process.color_ramp = texture
		spray.process_material = process
		var quad = QuadMesh.new()
		quad.size = Vector2.ONE
		var mat = StandardMaterial3D.new()
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.vertex_color_use_as_albedo = true
		mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
		mat.albedo_color = Color(0.9,0.97,1,0.55)
		var puff_gradient = Gradient.new()
		puff_gradient.set_color(0,Color(1,1,1,0.65))
		puff_gradient.add_point(0.3,Color(1,1,1,0.25))
		puff_gradient.set_color(puff_gradient.get_point_count()-1,Color(1,1,1,0))
		var puff = GradientTexture2D.new()
		puff.gradient = puff_gradient
		puff.width = 32
		puff.height = 32
		puff.fill = GradientTexture2D.FILL_RADIAL
		puff.fill_from = Vector2(0.5,0.5)
		puff.fill_to = Vector2(1,0.5)
		mat.albedo_texture = puff
		quad.material = mat
		spray.draw_pass_1 = quad
		spray.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(spray)
		sprays.append(spray)
	tracks = MultiMesh.new()
	tracks.transform_format = MultiMesh.TRANSFORM_3D
	var mesh = BoxMesh.new()
	mesh.size = Vector3(0.065,0.012,1.6)
	var track_mat = lighting.material(Color("bdcfdb"),1.0)
	mesh.material = track_mat
	tracks.mesh = mesh
	tracks.instance_count = 800
	for i in range(800):
		tracks.set_instance_transform(i, Transform3D(Basis.IDENTITY.scaled(Vector3.ZERO), Vector3.ZERO))
	var instance = MultiMeshInstance3D.new()
	instance.multimesh = tracks
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)
	audio_wind = _audio("res://assets/wind.wav")
	audio_ski = _audio("res://assets/ski.wav")
	# Separate scrape layer stays quiet on a clean line and bites under edge load.
	audio_edge = _audio("res://assets/ski.wav")
	audio_rain = _audio("res://assets/rain.wav")

func _audio(path: String) -> AudioStreamPlayer:
	var player = AudioStreamPlayer.new()
	# Headless tests have no audio device; avoid starting looping playbacks on
	# the dummy audio driver (which cannot drain them during scene teardown).
	if DisplayServer.get_name() == "headless":
		add_child(player)
		return player
	var stream = load(path) as AudioStreamWAV
	if stream:
		stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
		stream.loop_begin = 0
		stream.loop_end = stream.data.size() / 2
	player.stream = stream
	player.volume_db = -60.0
	add_child(player)
	player.play()
	return player

func reset() -> void:
	last_track = Vector3.INF
	for spray in sprays:
		spray.restart()
	for pad in Input.get_connected_joypads():
		Input.stop_joy_vibration(pad)

func update_effects(sim, field, position_value: Vector3, dt: float, active: bool, weather = null) -> void:
	var speed: float = sim.velocity.length()
	var ratio = clampf(sim.speed_kmh() / 200.0, 0.0, 1.0)
	var racing = smoothstep(60.0, 150.0, sim.speed_kmh())
	var slip = absf(sin(sim.slip_angle))
	var forward: Vector3 = sim.ski_forward
	var right: Vector3 = sim.surface_normal.cross(forward).normalized()
	var basis_value = Basis(right,sim.surface_normal,forward)
	for i in range(sprays.size()):
		var spray = sprays[i]
		spray.position = position_value + right * (-0.24 if i == 0 else 0.24) + sim.surface_normal * 0.09
		spray.basis = basis_value
		spray.emitting = active and sim.grounded and speed > 1.5 and not sim.crashed
		spray.amount_ratio = clampf(0.04 + racing * 0.25 + slip * 0.7 + sim.edge_load * 0.20 + sim.landing_force * 0.09,0.0,1.0)
		var process: ParticleProcessMaterial = spray.process_material
		process.initial_velocity_max = 1.5 + speed * 0.10 + slip * 6.0 + sim.landing_force * 0.5
		process.scale_max = 0.065 + slip * 0.12 + sim.landing_force * 0.008
	if active and sim.grounded and not sim.crashed and position_value.distance_to(last_track) > 1.4:
		for side in [-1,1]:
			var p = position_value + right * side * 0.22
			p.y = field.sample(p.x,p.z).height + 0.018
			tracks.set_instance_transform(track_cursor, Transform3D(basis_value,p))
			track_cursor = (track_cursor + 1) % tracks.instance_count
		last_track = position_value
	var audible = active and not muted and not sim.crashed
	var wind_db = lerpf(-48.0,-7.0,pow(ratio,0.72)) if audible else -65.0
	if audible:
		var gust: float = weather.gust if weather != null else 0.0
		var weather_wind: float = weather.wind_velocity.length() if weather != null else 0.0
		if weather != null and weather.enabled:
			wind_db = minf(-5.5, wind_db + smoothstep(90.0,200.0,sim.speed_kmh()) * 1.5 + gust * 1.2)
			wind_db = maxf(wind_db, -43.0 + minf(weather_wind,15.0))
	var ski_db = lerpf(-39.0,-22.0,smoothstep(0.0,90.0,sim.speed_kmh())) + minf(sim.landing_force,6.0) if audible and sim.grounded else -65.0
	var edge_db = -42.0 + sim.edge_load * 11.0 + slip * 12.0 + minf(sim.landing_force,8.0) if audible and sim.grounded and speed>2.0 else -65.0
	audio_wind.volume_db = lerpf(audio_wind.volume_db,wind_db,1.0-exp(-dt*5.0))
	audio_wind.pitch_scale = 0.7 + ratio * 0.7
	var rain: float = weather.rain if weather != null and weather.enabled else 0.0
	var rain_db: float = lerpf(-42.0,-17.0,sqrt(rain)) if audible and rain>0.001 else -65.0
	audio_rain.volume_db = lerpf(audio_rain.volume_db,rain_db,1.0-exp(-dt*5.0))
	audio_ski.volume_db = lerpf(audio_ski.volume_db,ski_db,1.0-exp(-dt*8.0))
	audio_ski.pitch_scale = 0.85 + ratio * 0.9 + slip * 0.2
	audio_edge.volume_db = lerpf(audio_edge.volume_db,edge_db,1.0-exp(-dt*12.0))
	audio_edge.pitch_scale = 1.5 + sim.edge_load * 0.45 + slip * 0.6
	haptic_clock += dt
	if haptic_clock > 0.1:
		haptic_clock = 0.0
		for pad in Input.get_connected_joypads():
			if active:
				var strength: float = sim.tuning.vibration_intensity
				Input.start_joy_vibration(pad, minf(1.0,ratio*ratio*0.30+(sim.edge_load*0.28+slip*0.35)*float(sim.grounded))*strength, minf(1.0,sim.landing_force*0.10+sim.balance_pressure*0.12+float(sim.crashed))*strength,0.11)
			else:
				Input.stop_joy_vibration(pad)
