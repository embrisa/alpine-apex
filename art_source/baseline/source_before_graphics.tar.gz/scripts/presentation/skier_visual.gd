extends Node3D
## Procedural pose follows edge, contact and tuck. Animation never drives motion.
var body_pivot = Node3D.new()
var torso: MeshInstance3D
var head: MeshInstance3D
var goggles: MeshInstance3D
var limbs: Array = []
var skis: Array = []
var poles: Array = []
var lighting = preload("res://scripts/presentation/cloud_lighting.gd").new()

func _ready() -> void:
	add_child(body_pivot)
	var jacket = _mat(Color("ed5b32"))
	var trousers = _mat(Color("183444"))
	var helmet = _mat(Color("172731"))
	var visor = _mat(Color("f9be51"), 0.25)
	for side in [-1.0, 1.0]:
		var ski = MeshInstance3D.new()
		ski.mesh = _ski_mesh()
		ski.material_override = _mat(Color("253d48"),0.32)
		ski.position = Vector3(side * 0.22, 0.065, 0.15)
		add_child(ski)
		skis.append(ski)
		var stripe = _box(Vector3(0.09, 0.004, 0.20), _mat(Color("c2e76b")))
		stripe.position = Vector3(0,0.026,0.53)
		ski.add_child(stripe)
		var binding = _box(Vector3(0.15, 0.15, 0.3), helmet)
		binding.position = Vector3(side * 0.22, 0.17, 0)
		body_pivot.add_child(binding)
		for i in range(4):
			var limb = _capsule(0.085 if i < 2 else 0.064, 0.5, trousers if i < 2 else jacket)
			body_pivot.add_child(limb)
			limbs.append(limb)
		var pole = _capsule(0.012, 1.2, helmet)
		body_pivot.add_child(pole)
		poles.append(pole)
	torso = _capsule(0.235, 0.60, jacket)
	body_pivot.add_child(torso)
	var backpack = _box(Vector3(0.31, 0.38, 0.13), _mat(Color("243b49")))
	backpack.position = Vector3(0, 0.01, -0.22)
	torso.add_child(backpack)
	head = _capsule(0.155, 0.33, helmet)
	body_pivot.add_child(head)
	goggles = _box(Vector3(0.27, 0.10, 0.09), visor)
	goggles.position = Vector3(0, 0.035, 0.145)
	head.add_child(goggles)

func _ski_mesh() -> ArrayMesh:
	# Curved shovel and tapered tail remain visible in the first-person view.
	var sections = [Vector3(-1.0,0.045,0.0),Vector3(-0.88,0.060,0.0),Vector3(0.0,0.052,0.0),Vector3(0.68,0.067,0.008),Vector3(0.95,0.071,0.055),Vector3(1.12,0.054,0.15),Vector3(1.18,0.008,0.20)]
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in range(sections.size()-1):
		var a: Vector3 = sections[i]
		var b: Vector3 = sections[i+1]
		var points = [Vector3(-a.y,a.z,a.x),Vector3(a.y,a.z,a.x),Vector3(-b.y,b.z,b.x),Vector3(b.y,b.z,b.x)]
		for idx in [0,1,2,1,3,2]:
			st.add_vertex(points[idx])
	st.generate_normals()
	st.index()
	return st.commit()

func _mat(color: Color, roughness: float = 0.65) -> ShaderMaterial:
	return lighting.material(color,roughness)

func _capsule(radius: float, height_value: float, mat: Material) -> MeshInstance3D:
	var mesh = CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = height_value
	mesh.radial_segments = 10
	mesh.rings = 3
	var node = MeshInstance3D.new()
	node.mesh = mesh
	node.material_override = mat
	return node

func _box(size_value: Vector3, mat: Material) -> MeshInstance3D:
	var mesh = BoxMesh.new()
	mesh.size = size_value
	var node = MeshInstance3D.new()
	node.mesh = mesh
	node.material_override = mat
	return node

func _bone(node: MeshInstance3D, a: Vector3, b: Vector3) -> void:
	node.position = (a + b) * 0.5
	var up = (b - a).normalized()
	var right = Vector3.FORWARD.cross(up).normalized()
	node.basis = Basis(right, up, right.cross(up).normalized())
	node.scale.y = a.distance_to(b) / 0.5

func pose(sim, intent, visual_position: Vector3, dt: float) -> void:
	position = visual_position
	var up: Vector3 = sim.surface_normal if sim.grounded else Vector3.UP
	var forward = Vector3(sin(sim.heading),-(up.x*sin(sim.heading)+up.z*cos(sim.heading))/maxf(up.y,0.05),cos(sim.heading)).normalized()
	var right = up.cross(forward).normalized()
	var target = Basis(right, up, forward)
	basis = basis.slerp(target, 1.0 - exp(-18.0 * dt)).orthonormalized()
	var tuck: float = sim.effective_tuck
	var crouch = tuck * 0.29 + clampf((sim.normal_load / 9.81 - 1.0) * 0.06 + sim.landing_force * 0.025, -0.05, 0.16)
	var lean = -sim.edge_angle * 0.36
	body_pivot.rotation.z = lean
	if sim.crashed:
		body_pivot.rotation.z = lerpf(body_pivot.rotation.z, -1.25, minf(dt * 7.0, 1.0))
		body_pivot.position.y = -0.2
	else:
		body_pivot.position.y = 0.0
	var hip = Vector3(0, 0.83 - crouch, -0.05)
	var shoulder = Vector3(0, 1.28 - crouch, 0.14 + tuck * 0.25)
	torso.position = (hip + shoulder) * 0.5
	torso.rotation.x = 0.23 + tuck * 0.57
	head.position = shoulder + Vector3(0, 0.21, 0.06 + tuck * 0.12)
	for i in range(2):
		var side = -1.0 if i == 0 else 1.0
		var ankle = Vector3(side * 0.22, 0.2, 0)
		var knee = Vector3(side * 0.20, 0.5 - crouch * 0.3, 0.25)
		var elbow = shoulder + Vector3(side * (0.31 - tuck * 0.06), -0.18, 0.05)
		var hand = shoulder + Vector3(side * (0.40 - tuck * 0.21), -0.29, 0.24)
		_bone(limbs[i * 4], ankle, knee)
		_bone(limbs[i * 4 + 1], knee, hip + Vector3(side * 0.16, 0, 0))
		_bone(limbs[i * 4 + 2], shoulder + Vector3(side * 0.19, 0, 0), elbow)
		_bone(limbs[i * 4 + 3], elbow, hand)
		_bone(poles[i], hand, hand + Vector3(side * 0.10, -0.36, -0.57))
		skis[i].rotation.z = -sim.edge_angle * 0.30
