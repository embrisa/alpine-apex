class_name SkiSimulation
extends RefCounted
const MODEL_VERSION = 3
## A constrained point-mass ski model, independent of rendering and the scene tree.
## Heading is ski orientation; velocity is never assigned from heading or input.
## The surface provides sample(x,z) -> {height, normal} and sweep_obstacle(from,to).
var tuning: SkiTuning
var position: Vector3 = Vector3.ZERO
var velocity: Vector3 = Vector3.ZERO
var heading: float = 0.0
var edge_angle: float = 0.0
var grounded: bool = true
var crashed: bool = false
var crash_reason: String = ""
var balance: float = 1.0
var airtime: float = 0.0
var total_airtime: float = 0.0
var peak_speed: float = 0.0
var acceleration: float = 0.0
var slip_angle: float = 0.0
var slope_angle: float = 0.0
var normal_load: float = 9.81
var friction_force: float = 0.0
var gravity_contribution: float = 0.0
var landing_force: float = 0.0
var effective_tuck: float = 0.0
var edge_load: float = 0.0
var lateral_acceleration: float = 0.0
var balance_pressure: float = 0.0
var surface_normal: Vector3 = Vector3.UP
var fall_line: Vector3 = Vector3.FORWARD
var ski_forward: Vector3 = Vector3.BACK
var gravity_vector: Vector3 = Vector3.DOWN * 9.81
var ticks: int = 0

func _init(values: SkiTuning = null) -> void:
	tuning = values if values != null else SkiTuning.new()

func reset(spawn: Vector3, yaw: float = 0.0) -> void:
	position = spawn
	velocity = Vector3.ZERO
	heading = yaw
	edge_angle = 0.0
	grounded = true
	crashed = false
	crash_reason = ""
	balance = 1.0
	airtime = 0.0
	total_airtime = 0.0
	peak_speed = 0.0
	acceleration = 0.0
	slip_angle = 0.0
	landing_force = 0.0
	effective_tuck = 0.0
	edge_load = 0.0
	lateral_acceleration = 0.0
	balance_pressure = 0.0
	friction_force = 0.0
	gravity_contribution = 0.0
	normal_load = 9.81
	ticks = 0

func step(dt: float, intent: RiderInput, surface) -> void:
	if crashed:
		return
	ticks += 1
	var old_position = position
	var old_speed = velocity.length()
	var n: Vector3 = _contact_normal(surface,position.x,position.z)
	surface_normal = n
	gravity_vector = Vector3.DOWN * 9.81 * tuning.gravity_multiplier
	var downhill = gravity_vector.slide(n)
	fall_line = downhill.normalized()
	slope_angle = rad_to_deg(acos(clampf(n.y, -1.0, 1.0)))
	landing_force = move_toward(landing_force, 0.0, dt * 12.0)
	# Opening the stance to turn/brake sacrifices the deepest aerodynamic tuck.
	# A tuck reduces available edging leverage; it is never a throttle.
	var tuck_target = clampf(intent.tuck, 0.0, 1.0) * (1.0 - 0.75 * smoothstep(0.12, 0.85, absf(intent.steer))) * (1.0 - clampf(intent.brake, 0.0, 1.0))
	effective_tuck = lerpf(effective_tuck, tuck_target, 1.0 - exp(-tuning.tuck_response * dt))
	edge_load = 0.0
	lateral_acceleration = 0.0
	balance_pressure = 0.0
	var steer_rate = tuning.steering_sensitivity / (1.0 + old_speed * tuning.high_speed_steering_reduction)
	# Air steering can orient the equipment but cannot steer the centre of mass.
	# Positive intent means rider-right. With forward=(sin(yaw),0,cos(yaw)),
	# rider-right is forward.cross(UP), so right turns DECREASE yaw.
	heading = wrapf(heading - intent.steer * steer_rate * dt * (1.0 if grounded else 0.42), -PI, PI)
	edge_angle = lerpf(edge_angle, -intent.steer * deg_to_rad(tuning.maximum_edge_angle), 1.0 - exp(-tuning.edge_response * lerpf(1.0, 0.70, effective_tuck) * dt))
	# Heading is a horizontal azimuth. Projecting a horizontal vector onto a
	# cross-slope changes that azimuth and silently steers the skis downhill.
	# Solve its vertical component instead, preserving the chosen compass line.
	ski_forward = Vector3(sin(heading), -(n.x * sin(heading) + n.z * cos(heading)) / maxf(n.y,0.05), cos(heading)).normalized()
	var side = n.cross(ski_forward).normalized()
	var forward_speed = velocity.dot(ski_forward)
	var side_speed = velocity.dot(side)
	slip_angle = atan2(side_speed, maxf(absf(forward_speed), 0.01))
	if grounded:
		# Curvature determines the contact force. Negative support means the snow
		# cannot pull the rider down: release into a ballistic trajectory at crests.
		var probe_normal = _contact_normal(surface,position.x + velocity.x * dt,position.z + velocity.z * dt)
		var curvature_accel = -velocity.dot(probe_normal - n) / dt
		normal_load = curvature_accel - gravity_vector.dot(n)
		if normal_load < tuning.minimum_load and old_speed > 3.0:
			grounded = false
		elif intent.jump:
			velocity += n * tuning.jump_impulse
			grounded = false
		else:
			velocity = velocity.slide(n)
			var edge = absf(edge_angle) / deg_to_rad(tuning.maximum_edge_angle)
			var grip_limit = maxf(normal_load, 0.0) * tuning.edge_grip * lerpf(0.42, 1.0, edge) * lerpf(1.0, tuning.tuck_grip_ratio, effective_tuck)
			var requested_grip = absf(side_speed) * tuning.carving_strength
			edge_load = clampf(requested_grip / maxf(grip_limit, 0.01), 0.0, 1.0)
			var lateral_accel = minf(requested_grip, grip_limit)
			# Clamp impulses to prevent reversing velocity, energy creation, or
			# oscillation near rest. Lateral force always dissipates slip energy.
			lateral_accel = minf(lateral_accel, absf(side_speed) / dt)
			lateral_acceleration = -signf(side_speed) * lateral_accel
			# Sideways stopping distance grows with squared slip velocity. Excess
			# beyond the rider's recovery room drains balance, especially unloaded
			# over terrain. No random wobble or speed-triggered failure.
			var slip_distance = side_speed * side_speed / (2.0 * maxf(grip_limit, 0.5))
			balance_pressure = clampf((slip_distance / tuning.lateral_recovery_distance - 1.0) * 0.55, 0.0, 2.0)
			velocity -= side * signf(side_speed) * lateral_accel * dt
			var skid_drag = tuning.skidding_friction * absf(sin(slip_angle)) * maxf(normal_load, 0.0)
			friction_force = tuning.ski_friction * maxf(normal_load, 0.0) * (1.0 + edge * edge * 0.4) + tuning.snow_resistance + skid_drag + intent.brake * tuning.braking_deceleration
			velocity = velocity.move_toward(Vector3.ZERO, friction_force * dt)
			# Static braking can hold on the test slope. Gravity is otherwise the
			# only source of downhill acceleration; tuck only changes air drag.
			if not (intent.brake > 0.8 and velocity.length() < 0.2 and downhill.length() < tuning.braking_deceleration):
				velocity += downhill * dt
			gravity_contribution = downhill.dot(velocity.normalized())
	if not grounded:
		velocity += gravity_vector * dt
		airtime += dt
		total_airtime += dt
		normal_load = 0.0
		friction_force = 0.0
		gravity_contribution = gravity_vector.dot(velocity.normalized())
	# Quadratic drag is integrated analytically for stability at extreme speeds.
	var drag = tuning.aerodynamic_drag * lerpf(1.0, tuning.tuck_drag_ratio, effective_tuck)
	velocity /= 1.0 + drag * velocity.length() * dt
	position += velocity * dt
	var next_ground = surface.sample(position.x, position.z)
	if grounded:
		position.y = next_ground.height
		# A passive surface cannot add kinetic energy when its normal changes.
		velocity = velocity.slide(_contact_normal(surface,position.x,position.z))
	elif position.y <= next_ground.height:
		# The short segment is swept against the heightfield to locate impact.
		var lo = 0.0
		var hi = 1.0
		for i in range(8):
			var mid = (lo + hi) * 0.5
			var p = old_position.lerp(position, mid)
			if p.y > surface.sample(p.x, p.z).height:
				lo = mid
			else:
				hi = mid
		position = old_position.lerp(position, hi)
		var contact = surface.sample(position.x, position.z)
		position.y = contact.height
		var impact = maxf(0.0, -velocity.dot(contact.normal))
		landing_force = impact
		var tolerance = tuning.landing_tolerance * (1.0 + effective_tuck * tuning.landing_absorption)
		var bad_alignment = absf(sin(slip_angle)) * velocity.length() * 0.16
		if impact + bad_alignment > tolerance:
			crash("HARD LANDING")
		else:
			balance = maxf(0.0, balance - (impact + bad_alignment) / tolerance * 0.55)
			velocity = velocity.slide(contact.normal) * (1.0 - minf(0.25, bad_alignment * 0.025))
			grounded = true
			airtime = 0.0
	# Loss of balance requires sustained large sideways slip; clean high-speed
	# carving is never penalized by a speed threshold or random crash roll.
	balance = clampf(balance + (tuning.balance_recovery - balance_pressure) * dt, 0.0, 1.0)
	if balance <= 0.0:
		crash("LOST EDGE")
	var hit: String = surface.sweep_obstacle(old_position, position)
	if not hit.is_empty():
		crash(hit)
	peak_speed = maxf(peak_speed, velocity.length())
	acceleration = (velocity.length() - old_speed) / dt

func crash(reason: String) -> void:
	crashed = true
	crash_reason = reason

func speed_kmh() -> float:
	return velocity.length() * 3.6

func _contact_normal(surface,x: float,z: float) -> Vector3:
	if surface.has_method("contact_normal"):
		return surface.contact_normal(x,z)
	return surface.sample(x,z).normal
