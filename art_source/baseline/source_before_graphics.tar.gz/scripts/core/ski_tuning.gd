class_name SkiTuning
extends Resource
## SI units: metres, seconds, radians, acceleration in m/s². No speed cap.
@export_group("Gravity and resistance")
@export_range(0.3, 2.0) var gravity_multiplier: float = 1.0
@export_range(0.001, 0.15) var ski_friction: float = 0.022
@export_range(0.0, 2.0) var snow_resistance: float = 0.08
# Quadratic drag coefficient in 1/m. Racing speed needs a sustained steep pitch.
@export_range(0.0001, 0.02) var aerodynamic_drag: float = 0.0058
@export_range(0.1, 1.0) var tuck_drag_ratio: float = 0.43
@export var tuck_response: float = 3.5
@export_range(0.1, 1.0) var tuck_grip_ratio: float = 0.76

@export_group("Edges and steering")
@export_range(0.2, 4.0) var edge_grip: float = 1.6
@export_range(1.0, 25.0) var carving_strength: float = 9.0
@export_range(0.0, 3.0) var skidding_friction: float = 0.6
@export_range(20.0, 80.0) var maximum_edge_angle: float = 62.0
@export_range(0.3, 3.0) var steering_sensitivity: float = 1.35
@export var high_speed_steering_reduction: float = 0.045
@export var edge_response: float = 14.0
@export var braking_deceleration: float = 8.2

@export_group("Contact and impacts")
@export var jump_impulse: float = 3.2
@export var landing_tolerance: float = 10.5
@export var landing_absorption: float = 0.25
@export var balance_recovery: float = 0.3
@export var lateral_recovery_distance: float = 2.5
@export var minimum_load: float = -0.5

@export_group("Presentation")
@export var camera_response: float = 7.5
@export var base_fov: float = 72.0
@export var speed_fov: float = 15.0
@export var vibration_intensity: float = 0.5
@export var speed_thresholds: PackedFloat32Array = PackedFloat32Array([30, 60, 90, 120, 150, 165, 200])
