extends RefCounted
## A single benchmark descent. Future races can replace the plane with ordered
## swept gate volumes without changing the integrator or time representation.
const SCHEMA_VERSION = 1
var elapsed: float = 0.0
var finish_z: float = 1450.0
var finished: bool = false
var personal_best: float = -1.0
var history: Array = []
var eligible: bool = true
var course_id: String = "laboratory-v%d-physics-v%d-default" % [preload("res://scripts/world/test_slope.gd").GENERATOR_VERSION, preload("res://scripts/core/ski_simulation.gd").MODEL_VERSION]

func reset() -> void:
	elapsed = 0.0
	finished = false
	eligible = true

func step(dt: float, before: Vector3, after: Vector3) -> bool:
	if finished:
		return false
	var fraction = clampf((finish_z-before.z)/maxf(after.z-before.z,0.00001),0,1)
	var crossing = before.lerp(after,fraction)
	if before.z < finish_z and after.z >= finish_z and absf(crossing.x) <= 36.0:
		elapsed += dt * fraction
		finished = true
		if eligible:
			history.push_front(elapsed)
			if history.size() > 20:
				history.resize(20)
			if personal_best < 0.0 or elapsed < personal_best:
				personal_best = elapsed
			save_record()
		return true
	elapsed += dt
	return false

func load_record() -> void:
	if not FileAccess.file_exists("user://benchmark_v1.json"):
		return
	var data = JSON.parse_string(FileAccess.get_file_as_string("user://benchmark_v1.json"))
	if data is Dictionary and data.get("version") == SCHEMA_VERSION and data.get("course") == course_id:
		personal_best = float(data.get("best", -1.0))
		history = data.get("history", []) if data.get("history", []) is Array else []

func save_record() -> void:
	var file = FileAccess.open("user://benchmark_v1.json", FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify({"version": SCHEMA_VERSION, "course": course_id, "best": personal_best, "history": history}, "\t"))

static func format_time(seconds: float) -> String:
	if seconds < 0.0:
		return "— — : — — . — — —"
	var ms = roundi(seconds * 1000.0)
	return "%02d:%02d.%03d" % [ms / 60000, (ms / 1000) % 60, ms % 1000]
