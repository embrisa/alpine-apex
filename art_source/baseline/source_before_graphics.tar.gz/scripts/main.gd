extends Node3D
const Terrain = preload("res://scripts/world/test_slope.gd")
const World = preload("res://scripts/world/alpine_world.gd")
const Simulation = preload("res://scripts/core/ski_simulation.gd")
const Router = preload("res://scripts/core/input_router.gd")
const Session = preload("res://scripts/core/run_session.gd")
const Visual = preload("res://scripts/presentation/skier_visual.gd")
const ChaseCamera = preload("res://scripts/presentation/chase_camera.gd")
const Effects = preload("res://scripts/presentation/speed_effects.gd")
const Vectors = preload("res://scripts/presentation/debug_vectors.gd")
const HUD = preload("res://scripts/ui/hud.gd")
const Weather = preload("res://scripts/presentation/weather_controller.gd")
const WeatherEffects = preload("res://scripts/presentation/weather_effects.gd")
var weather
var weather_effects
var field
var world
var sim: SkiSimulation
var input_router
var session
var skier
var camera
var effects
var vectors
var hud
var intent = RiderInput.new()
var active: bool = false
var timed: bool = true
var physics_modified: bool = false
var previous_position: Vector3
var cpu_tick_ms: float = 0.0
var frame_ms: float = 0.0
var frame_samples: Array[float] = []
var gpu_samples: Array[float] = []
var render_cpu_samples: Array[float] = []
var automated: bool = false
var automated_ticks: int = 0
var screenshot_ticks: Array = [1,1200,2400,4200,6000]
var render_frames: int = 0
var last_frame_usec: int = 0
var jump_armed: bool = false
var workbench_return: String = "title"
var speed_periphery: ColorRect
var effect_time: float = 0.0
var quitting: bool = false

func _ready() -> void:
	get_tree().auto_accept_quit = false
	input_router = Router.new()
	var values = preload("res://config/ski_default.tres").duplicate(true)
	sim = Simulation.new(values)
	field = Terrain.new()
	world = World.new()
	add_child(world)
	world.build(field)
	weather = Weather.new()
	add_child(weather)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--time-of-day="):
			weather.set_time_of_day(arg.get_slice("=",1))
		elif arg == "--cloud-shadows-off":
			world.cloud_lighting.shadow_strength = 0.0
		elif arg.begins_with("--weather="):
			weather.set_preset(arg.get_slice("=",1))
		elif arg.begins_with("--weather-quality="):
			var quality_id = ["off","low","high"].find(arg.get_slice("=",1))
			if quality_id >= 0:
				weather.set_quality(quality_id)
	weather.set_automatic("--weather-auto" in OS.get_cmdline_user_args())
	weather.set_time_cycle("--time-cycle" in OS.get_cmdline_user_args())
	session = Session.new()
	session.load_record()
	skier = Visual.new()
	skier.lighting = world.cloud_lighting
	add_child(skier)
	camera = ChaseCamera.new()
	camera.near = 0.15
	camera.far = 8500.0
	add_child(camera)
	camera.current = true
	effects = Effects.new()
	effects.lighting = world.cloud_lighting
	add_child(effects)
	weather_effects = WeatherEffects.new()
	add_child(weather_effects)
	vectors = Vectors.new()
	add_child(vectors)
	vectors.visible = false
	var motion_layer = CanvasLayer.new()
	motion_layer.layer = 0
	add_child(motion_layer)
	speed_periphery = ColorRect.new()
	speed_periphery.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	speed_periphery.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var motion_material = ShaderMaterial.new()
	motion_material.shader = preload("res://assets/speed_periphery.gdshader")
	speed_periphery.material = motion_material
	motion_layer.add_child(speed_periphery)
	hud = HUD.new()
	add_child(hud)
	hud.build_tuning(values)
	hud.start_requested.connect(start_run)
	hud.restart_requested.connect(restart)
	hud.resume_requested.connect(resume)
	hud.lab_speed_requested.connect(start_speed_lab)
	hud.tuning_changed.connect(func(): physics_modified = true; session.eligible = false)
	hud.defaults_requested.connect(func(): physics_modified = false; restart())
	hud.workbench_closed.connect(close_workbench)
	hud.quit_requested.connect(quit_cleanly)
	hud.weather_preset_requested.connect(weather.set_preset)
	hud.weather_auto_requested.connect(weather.set_automatic)
	hud.weather_quality_requested.connect(weather.set_quality)
	hud.time_of_day_requested.connect(weather.set_time_of_day)
	hud.time_cycle_requested.connect(weather.set_time_cycle)
	weather.settings_changed.connect(func(): hud.sync_weather(weather))
	hud.sync_weather(weather)
	sim.reset(field.spawn_point())
	previous_position = sim.position
	print("ALPINE APEX | terrain %.1f ms | %d triangles | %d obstacles | 120 Hz" % [world.generation_ms,world.terrain_triangles,field.obstacles.size()])
	if "--autoplay" in OS.get_cmdline_user_args():
		get_window().size = Vector2i(1440,900)
		get_window().unresizable = true
		RenderingServer.viewport_set_measure_render_time(get_viewport().get_viewport_rid(),true)
		automated = true
		start_run(true)
		session.eligible = false
		camera.close_view = "--first-person" in OS.get_cmdline_user_args()
	if "--capture-menu" in OS.get_cmdline_user_args():
		_capture_menu.call_deferred()

func _physics_process(dt: float) -> void:
	if sim == null or not active:
		return
	var tick_start = Time.get_ticks_usec()
	previous_position = sim.position
	intent = input_router.sample()
	if not Input.is_action_pressed("jump"):
		jump_armed = true
	intent.jump = intent.jump and jump_armed
	if automated:
		# Benchmark input is fixed even if someone types while its window is
		# focused. Physical keyboard/gamepad input must not alter comparisons.
		intent = RiderInput.new()
		intent.tuck = 1.0
		automated_ticks += 1
	sim.step(dt,intent,field)
	if timed and not sim.crashed:
		var completed: bool = session.step(dt,previous_position,sim.position)
		if completed:
			active = false
			hud.show_menu("finished","%s  /  TOP SPEED %d km/h\n%s" % [Session.format_time(session.elapsed),sim.peak_speed*3.6,"Benchmark recorded. Keep finding time." if session.eligible else "Lab run. Personal best unchanged."])
	elif not timed:
		session.elapsed += dt
	if sim.crashed:
		active = false
		hud.show_menu("crashed",sim.crash_reason)
	cpu_tick_ms = lerpf(cpu_tick_ms,(Time.get_ticks_usec()-tick_start)/1000.0,0.05)
	if automated:
		if automated_ticks in screenshot_ticks:
			_capture("run_%04d" % automated_ticks)
		if sim.crashed or session.finished or automated_ticks > 9000:
			_finish_automation.call_deferred()

func _process(dt: float) -> void:
	if sim == null:
		return
	render_frames += 1
	var now = Time.get_ticks_usec()
	var measured_frame_ms = float(now-last_frame_usec)/1000.0 if last_frame_usec>0 else dt*1000.0
	last_frame_usec = now
	frame_ms = lerpf(frame_ms,dt*1000.0,0.07)
	if automated and render_frames > 120:
		frame_samples.append(measured_frame_ms)
		var viewport_rid = get_viewport().get_viewport_rid()
		var gpu_ms = RenderingServer.viewport_get_measured_render_time_gpu(viewport_rid)
		var render_cpu_ms = RenderingServer.viewport_get_measured_render_time_cpu(viewport_rid)
		if gpu_ms>0.0:
			gpu_samples.append(gpu_ms)
		if render_cpu_ms>0.0:
			render_cpu_samples.append(render_cpu_ms)
	# Rendering interpolates between completed 120 Hz states: at most 8.33 ms
	# of interpolation latency, with input sampled at each physics tick.
	var fraction = Engine.get_physics_interpolation_fraction()
	var p = previous_position.lerp(sim.position,fraction) if active else sim.position
	skier.pose(sim,intent,p,dt)
	skier.body_pivot.visible = not camera.close_view
	var title: bool = (hud.menu.visible or hud.weather_panel.visible) and hud.menu_mode == "title"
	camera.update_camera(sim,field,p,dt,title,active)
	weather.update_weather(dt,active,title)
	world.update_weather(weather.state,dt,active or title)
	weather_effects.update_weather(weather.state,camera,p,field,dt,active,title,camera.motion_intensity if camera.effects_enabled else 0.0,weather.quality)
	speed_periphery.visible = active and camera.effects_enabled and camera.motion_intensity>0.005
	speed_periphery.material.set_shader_parameter("intensity",camera.motion_intensity)
	if active:
		effect_time += dt
	speed_periphery.material.set_shader_parameter("arcade_intensity",camera.motion_intensity if active and camera.effects_enabled and weather.state.enabled else 0.0)
	speed_periphery.material.set_shader_parameter("effect_time",effect_time)
	effects.update_effects(sim,field,p,dt,active,weather.state)
	vectors.update_vectors(sim)
	hud.update_hud(sim,session,intent,input_router.device_label(),frame_ms,cpu_tick_ms,dt,timed,weather.state.label+" · "+weather.state.time_label)

func _unhandled_input(event: InputEvent) -> void:
	if automated:
		return
	if event.is_action_pressed("restart"):
		restart()
	elif event.is_action_pressed("pause_run"):
		if hud.weather_panel.visible:
			hud.close_weather()
		elif hud.tuning_panel.visible:
			close_workbench()
		elif active:
			active = false
			hud.show_menu("paused")
		elif hud.menu_mode == "paused":
			resume()
	elif event.is_action_pressed("begin_run") and hud.menu.visible:
		hud._primary_pressed()
	elif event.is_action_pressed("camera_mode"):
		camera.close_view = not camera.close_view
		camera.reset()
		weather_effects.reset()
		hud.toast("FIRST PERSON" if camera.close_view else "CHASE CAMERA")
	elif event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_V:
		camera.effects_enabled = not camera.effects_enabled
		hud.toast("MOTION EFFECTS ON" if camera.effects_enabled else "MOTION EFFECTS OFF")
	elif event.is_action_pressed("debug_overlay"):
		hud.debug_panel.visible = not hud.debug_panel.visible
		vectors.visible = hud.debug_panel.visible
	elif event.is_action_pressed("tuning"):
		if hud.tuning_panel.visible:
			close_workbench()
		else:
			workbench_return = "active" if active else hud.menu_mode
			hud.tuning_panel.visible = true
			active = false
			hud.hide_menu()
	elif event.is_action_pressed("toggle_audio"):
		effects.muted = not effects.muted
		hud.toast("AUDIO MUTED" if effects.muted else "AUDIO ON")
	elif event.is_action_pressed("toggle_hud"):
		hud.toggle_instruments()

func start_run(is_timed: bool = true) -> void:
	timed = is_timed
	restart()

func restart() -> void:
	sim.reset(field.spawn_point())
	session.reset()
	session.eligible = not physics_modified and not automated
	previous_position = sim.position
	intent = RiderInput.new()
	jump_armed = false
	camera.reset()
	effects.reset()
	weather_effects.reset()
	effect_time = 0.0
	hud.hide_menu()
	hud.tuning_panel.visible = false
	active = true

func resume() -> void:
	if sim.crashed or session.finished:
		hud.show_menu("crashed" if sim.crashed else "finished",sim.crash_reason if sim.crashed else Session.format_time(session.elapsed))
		return
	hud.hide_menu()
	previous_position = sim.position
	active = true

func start_speed_lab(kmh: float) -> void:
	restart()
	session.eligible = false
	var normal: Vector3 = field.sample(sim.position.x,sim.position.z).normal
	sim.velocity = Vector3.DOWN.slide(normal).normalized() * kmh / 3.6
	hud.toast("SPEED LAB  /  %d km/h  /  UNRANKED" % kmh)

func close_workbench() -> void:
	hud.tuning_panel.visible = false
	if workbench_return == "active":
		resume()
	else:
		hud.show_menu(workbench_return,sim.crash_reason if sim.crashed else Session.format_time(session.elapsed))

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		quit_cleanly()
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and active and not automated:
		active = false
		if hud:
			hud.show_menu("paused")

func quit_cleanly() -> void:
	if quitting:
		return
	quitting = true
	active = false
	automated = false
	if effects:
		effects.stop_audio()
	# Let the native audio callback release its loop playbacks before the
	# engine's Resource/ObjectDB cleanup (headless has no playback thread).
	if DisplayServer.get_name() != "headless":
		await get_tree().create_timer(0.10).timeout
	get_tree().quit()

func _capture(label: String) -> void:
	await RenderingServer.frame_post_draw
	if DisplayServer.get_name() != "headless":
		print("CAPTURE ",label," rider=",sim.position," camera=",camera.position," distance=",camera.position.distance_to(sim.position))
		var img = get_viewport().get_texture().get_image()
		img.save_png("res://artifacts/%s.png" % label)

func _capture_menu() -> void:
	await get_tree().create_timer(2.0).timeout
	await _capture("menu")
	await quit_cleanly()

func _finish_automation() -> void:
	automated = false
	active = false
	await _capture("run_end")
	frame_samples.sort()
	var mean = 0.0
	for ms in frame_samples:
		mean += ms
	mean /= maxf(1.0,frame_samples.size())
	var data = {"engine":Engine.get_version_info().string,"renderer":RenderingServer.get_current_rendering_method(),"device":RenderingServer.get_video_adapter_name(),"resolution":str(get_viewport().get_visible_rect().size),"frames":frame_samples.size(),"mean_frame_ms":mean,"p95_frame_ms":frame_samples[int(frame_samples.size()*0.95)] if not frame_samples.is_empty() else 0.0,"p99_frame_ms":frame_samples[int(frame_samples.size()*0.99)] if not frame_samples.is_empty() else 0.0,"last_smoothed_tick_ms":cpu_tick_ms,"peak_kmh":sim.peak_speed*3.6,"airtime_s":sim.total_airtime,"run_time_s":session.elapsed,"crashed":sim.crashed,"reason":sim.crash_reason,"finished":session.finished,"world_build_ms":world.generation_ms}
	data.weather = weather.selected_preset
	data.weather_quality = weather.quality
	data.weather_particle_budget = weather_effects.particle_budget()
	data.time_hour = weather.daylight.hour
	data.cloud_shadow_strength = world.cloud_lighting.shadow_strength
	data.render_gpu_ms = _timing_summary(gpu_samples)
	data.render_cpu_ms = _timing_summary(render_cpu_samples)
	var output = "res://artifacts/render_benchmark.json"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--benchmark-label="):
			output = "res://artifacts/weather_benchmark_%s.json" % arg.get_slice("=",1).validate_filename()
	var file = FileAccess.open(output,FileAccess.WRITE)
	file.store_string(JSON.stringify(data,"\t"))
	print("RENDER_BENCHMARK ",JSON.stringify(data))
	await quit_cleanly()

func _timing_summary(samples: Array[float]) -> Dictionary:
	if samples.is_empty():
		return {"available":false}
	samples.sort()
	var total = 0.0
	for sample in samples:
		total += sample
	return {"available":true,"samples":samples.size(),"mean":total/samples.size(),"p95":samples[int(samples.size()*0.95)],"p99":samples[int(samples.size()*0.99)]}
